package ch.frox.pizzaprocess.main.java.entrypoint.dialog.administerpizzasdialog;

import static ch.frox.pizzaprocess.main.java.domain.pizza.PizzaStatus.ACTIVE;
import static ch.frox.pizzaprocess.main.java.domain.pizza.PizzaStatus.DEACTIVATED;
import static ch.frox.pizzaprocess.main.java.entrypoint.dialog.administerpizzasdialog.AdministerPizzasDialogPage.ACTIVE_PIZZAS_OVERVIEW_PAGE;
import static ch.frox.pizzaprocess.main.java.entrypoint.dialog.administerpizzasdialog.AdministerPizzasDialogPage.DEACTIVATED_PIZZAS_OVERVIEW_PAGE;
import static ch.frox.pizzaprocess.main.java.entrypoint.dialog.administerpizzasdialog.AdministerPizzasDialogPage.PIZZA_FORM_PAGE;

import java.util.List;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;

import ch.frox.pizzaprocess.AdministerPizzasDialog.AdministerPizzasDialogData;
import ch.frox.pizzaprocess.main.java.core.dependencyinjection.Registry;
import ch.frox.pizzaprocess.main.java.core.exception.ExceptionHandler;
import ch.frox.pizzaprocess.main.java.core.generic.GenericDialogBean;
import ch.frox.pizzaprocess.main.java.core.security.AuthorizationService;
import ch.frox.pizzaprocess.main.java.core.security.Permission;
import ch.frox.pizzaprocess.main.java.core.util.FileUtil;
import ch.frox.pizzaprocess.main.java.core.util.UserNotifier;
import ch.frox.pizzaprocess.main.java.domain.image.Image;
import ch.frox.pizzaprocess.main.java.domain.image.ImageService;
import ch.frox.pizzaprocess.main.java.domain.pizza.Pizza;
import ch.frox.pizzaprocess.main.java.domain.pizza.PizzaService;
import ch.frox.pizzaprocess.main.java.domain.pizza.PizzaSize;
import ch.frox.pizzaprocess.main.java.domain.pizza.query.PizzaFilter;
import jakarta.annotation.PreDestroy;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;



@Named("administerPizzasDialogBean")
@ViewScoped
public class AdministerPizzasDialogBean extends GenericDialogBean<AdministerPizzasDialogData, AdministerPizzasDialogPage> {
    private static final long serialVersionUID = 1L;
    private static final PizzaService pizzaService = Registry.get(PizzaService.class);
    private static final ImageService imageService = Registry.get(ImageService.class);
    private static final AuthorizationService authorizationService = Registry.get(AuthorizationService.class);
    private PizzaFilter filter;
    private List<Pizza> activePizzas;
    private List<Pizza> deactivatedPizzas;
    private Pizza formPizza;
    private boolean isNewPizza;
    private AdministerPizzasDialogPage previousePage;

    @Override
    protected void init() {
        previousePage = currentPage;
        filter = new PizzaFilter();
        reloadLists();
    }

    @PreDestroy
    private void destroy() {
        pizzaService.prune();
        if (currentPage == PIZZA_FORM_PAGE) discardUnsavedImage();
    }



    // |----- actions -----|

    public void deactivate(Pizza pizza) {
        if (ExceptionHandler.guard(() -> {
            pizzaService.deactivate(pizza);
        }, () -> {
            reloadLists();
        })) return;
    
        UserNotifier.message("Off the menu", "'" + pizza.getName() + "' is not on the menu anymore.");
    }

    public void activate(Pizza pizza) {
        if (ExceptionHandler.guard(() -> {
            pizzaService.activate(pizza);
        }, () -> {
            reloadLists();
        })) return;

        reloadLists();
        UserNotifier.message("On the menu", "'" + pizza.getName() + "' is on the menu now.");
    }

    public void delete(Pizza pizza) {
        if (ExceptionHandler.guard(() -> {
            pizzaService.delete(pizza);
        }, () -> {
            reloadLists();
        })) return;
        reloadLists();
        UserNotifier.message("Deleted", "'" + pizza.getName() + "' is gone for good.");
    }

    public void startNewPizzaForm() {
        openForm(new Pizza(), true);
    }

    public void startEditPizzaForm(Pizza pizza) {
        openForm(pizza.copyAsSameVersion(), false);
    }

    public void saveForm() {
        if (ExceptionHandler.guard(() -> {
            if (isNewPizza) pizzaService.save(formPizza);
            else pizzaService.update(formPizza);
        })) return;

        if (isNewPizza) {
            UserNotifier.message("Added", "'" + formPizza.getName() + "' is saved as deactivated. Put it on the menu once it's ready.");
        } else {
            UserNotifier.message("Saved", "'" + formPizza.getName() + "' is up to date.");
        }
        closeForm();
    }

    public void cancelForm() {
        discardUnsavedImage();
        closeForm();
    }

    public void uploadImage(FileUploadEvent event) {
        UploadedFile file = event.getFile();
        Image previousImage = formPizza.getImage();

        if (ExceptionHandler.guard(() -> {
            formPizza.setImage(imageService.save(file.getContent(), FileUtil.extensionOf(file.getFileName())));
        })) return;

        if (previousImage != null && !previousImage.getId().equals(formPizza.getImage().getId())) {
            imageService.deleteIfUnused(previousImage);
        }
    }



    // |----- search -----|

    public void search() {
        reloadLists();
    }

    public void clearFilter() {
        filter = new PizzaFilter();
        reloadLists();
    }



    // |----- routing -----|

    public void goToActivePizzasOverviewPage() {
        reloadLists();
        currentPage = ACTIVE_PIZZAS_OVERVIEW_PAGE;
    }

    public void goToDeactivatedPizzasOverviewPage() {
        reloadLists();
        currentPage = DEACTIVATED_PIZZAS_OVERVIEW_PAGE;
    }



    // |----- getters & setters -----|

    public PizzaFilter getFilter() {
        return filter;
    }

    public List<Pizza> getActivePizzas() {
        return activePizzas;
    }

    public List<Pizza> getDeactivatedPizzas() {
        return deactivatedPizzas;
    }

    public int getActivePizzaCount() {
        return activePizzas == null ? 0 : activePizzas.size();
    }

    public int getDeactivatedPizzaCount() {
        return deactivatedPizzas == null ? 0 : deactivatedPizzas.size();
    }

    public Pizza getFormPizza() {
        return formPizza;
    }

    public boolean isNewPizza() {
        return isNewPizza;
    }

    public PizzaSize[] getPossiblePizzaSizes() {
        return PizzaSize.values();
    }

    public String getFormTitle() {
        return isNewPizza ? "New pizza" : "Edit pizza";
    }

    public boolean isCustomerDataLocked() {
        return formPizza != null
            && formPizza.getStatus() == ACTIVE
            && !authorizationService.hasPermission(Permission.CHANGE_IMPORTANT_PIZZA_DATA_PERMISSON);
    }

    public boolean isFormImagePresent() {
        return formPizza != null && formPizza.getImage() != null;
    }



    // |----- helper methods -----|

    private void reloadLists() {
        ExceptionHandler.guard(() -> {
            activePizzas = pizzaService.getAll(filter, ACTIVE);
            deactivatedPizzas = pizzaService.getAll(filter, DEACTIVATED);
        });
    }

    private void openForm(Pizza pizza, boolean isNew) {
        if (currentPage != PIZZA_FORM_PAGE) previousePage = currentPage;
        formPizza = pizza;
        isNewPizza = isNew;
        currentPage = PIZZA_FORM_PAGE;
    }

    private void closeForm() {
        formPizza = null;
        isNewPizza = false;
        reloadLists();
        currentPage = previousePage;
    }

    private void discardUnsavedImage() {
        if (formPizza != null && formPizza.getImage() != null) imageService.deleteIfUnused(formPizza.getImage());
    }
}