package ch.frox.pizzaprocess.main.java.core.security;

import java.util.Objects;

import ch.frox.pizzaprocess.main.java.core.validation.constraint.AvailableUserName;
import ch.frox.pizzaprocess.main.java.core.validation.validationgroup.OnSignup;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;



/**
 * Object for the login and the signup of an axon ivy user. 
 * Its like a entity, tho the users live in the axon ivy security system.
**/
@Getter @Setter
public class Credentials {
    @NotBlank(message = "Please enter your username.")
    @Size(max = 40, message = "A username can have 40 characters at most.")
    @Pattern(regexp = "^[A-Za-z0-9._-]*$", message = "A username can only have letters, digits, '.', '_' and '-'.", groups = OnSignup.class)
    @AvailableUserName(groups = OnSignup.class)
    private String userName;

    @NotBlank(message = "Please enter your password.")
    @Size(min = 4, max = 64, message = "A password needs 4 to 64 characters.", groups = OnSignup.class)
    private String password;

    private String passwordRepeat;



    @AssertTrue(message = "The two passwords don't match.", groups = OnSignup.class)
    public boolean isPasswordRepeated() {
        return Objects.equals(password, passwordRepeat);
    }

    public void clear() {
        userName = null;
        password = null;
        passwordRepeat = null;
    }
}