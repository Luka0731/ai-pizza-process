package ch.frox.pizzaprocess.main.java.entrypoint.dialog.askforthepizzadialog;

import static ch.frox.pizzaprocess.main.java.domain.order.OrderStatus.DELIVERED;
import static ch.frox.pizzaprocess.main.java.domain.order.OrderStatus.PAID;

import ch.frox.pizzaprocess.AskForThePizzaDialog.AskForThePizzaDialogData;
import ch.frox.pizzaprocess.main.java.core.dependencyinjection.Registry;
import ch.frox.pizzaprocess.main.java.core.exception.ExceptionHandler;
import ch.frox.pizzaprocess.main.java.core.generic.GenericDialogBean;
import ch.frox.pizzaprocess.main.java.core.generic.preset.SingleDialogPage;
import ch.frox.pizzaprocess.main.java.core.util.UserNotifier;
import ch.frox.pizzaprocess.main.java.core.workflow.Signaler;
import ch.frox.pizzaprocess.main.java.domain.order.Order;
import ch.frox.pizzaprocess.main.java.domain.order.OrderService;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;



@Named("askForThePizzaDialogBean")
@ViewScoped
public class AskForThePizzaDialogBean extends GenericDialogBean<AskForThePizzaDialogData, SingleDialogPage> {
    private static final long serialVersionUID = 1L;
    private static final String DEFAULT_QUESTION = "Where is my pizza?";
    private static final OrderService orderService = Registry.get(OrderService.class);
    private Order order;
    private String question;

    @Override
    protected void init() {
        order = orderService.getById(dialogData.getOrderId());
    }



    // |----- actions -----|

    public void ask() {
        if (isQuestionAsked()) return;

        if (ExceptionHandler.guard(() -> {
            order = orderService.getById(order.getId());
        })) return;
        if (isPizzaHere()) return;

        Signaler.orderAsked(order.getId(), (question == null || question.isBlank())? DEFAULT_QUESTION : question.trim());

        // goes back to the process with close(), so the next "Where is my pizza?" task knows it too
        dialogData.setQuestionAsked(true);
        question = null;
        UserNotifier.message("Sent", "We got your question and answer by e-mail.");
    }



    // |----- getters & setters -----|

    public Order getOrder() {
        return order;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public boolean isQuestionAsked() {
        return Boolean.TRUE.equals(dialogData.getQuestionAsked());
    }

    public boolean isPizzaHere() {
        return order.getStatus() == DELIVERED || order.getStatus() == PAID;
    }
}