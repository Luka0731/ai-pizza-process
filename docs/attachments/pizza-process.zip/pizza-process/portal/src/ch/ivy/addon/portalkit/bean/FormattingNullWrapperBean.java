package ch.ivy.addon.portalkit.bean;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

import com.axonivy.portal.components.service.DateTimeGlobalSettingService;

import ch.ivyteam.ivy.environment.Ivy;

@Named
@ApplicationScoped
public class FormattingNullWrapperBean implements Serializable {
  private static final long serialVersionUID = 1L;

  private static final String DEFAULT_VALUE_IF_NULL = Ivy.cms().co("/ch.ivy.addon.portalkit.ui.jsf/common/notAvailable");
  
  public String format(Date date) {
    if (date == null) {
      return DEFAULT_VALUE_IF_NULL;
    }
    String pattern = DateTimeGlobalSettingService.getInstance().getGlobalDateTimePattern();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, Ivy.session().getFormattingLocale());
    return simpleDateFormat.format(date);
  }
}
